package boaventura.com.devel.br.flutteraudioquery.sortingtypes;

public enum GenreSortType  {
    DEFAULT,
}
